#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct matrix{
    int i;
    int j;
    float valor;
};

int main()
{
    struct matrix *celula;
    int lin, col, m, n, k=0, r, j=0, menu;
    int max_el, elem=1, pos_el;
    float novo, soma;
    char noyes;
    int buscar(int m, int n, int max_el, struct matrix *celula);
    float som_lin(int m, int elem, struct matrix *celula);
    float som_col(int n, int elem, struct matrix *celula);

    printf("             Ola usuario, eu sou o SUMMER\n(\"Sistema Unico de Multitarefas para Matrizes Esparsas Reais\")\n\n\n\n Primeiramente, vamos criar sua matriz!\n");
    while(k==0){
    printf("\nDigite o numero de linhas que sua matriz tera:\n");
    scanf("%d",&lin);
    fflush(stdin);
    printf("\nDigite o numero de colunas que sua matriz tera:\n");
    scanf("%d",&col);
    fflush(stdin);
    if(lin<=0||col<=0)printf("A matriz nao existe!!\n");
    else k++;
    }max_el=20;
    celula=(struct matrix*)malloc(max_el*sizeof(struct matrix));
    if(celula==NULL){printf("\n\n\nFALHA NO ARMAZENAMENTO EM MEMORIA!!!"); exit(1);}
    celula[0].i=0;
    celula[0].j=0;
    celula[0].j=0;
    printf("\nSua Matriz foi criada com sucesso\n(Todas as celulas estao preenchida com um valor \"0\" ate o momento)\n");
    k=0;
    do{ fflush(stdin);
        printf("\nO que deseja fazer agora?\n1 - Consultar/Editar valor de uma celula da matriz;\n2 - Consultar a soma dos valores de cada linha da matriz;\n3 - Consultar a soma dos valores de cada coluna da matriz;\n0 - Apagar matriz atual e encerrar programa\nNao feche o programa sem a selecao da funcao 0, isso pode trazer serios problemas a memoria ram do seu computador!!!\n");
        scanf("%d",&menu);
        fflush(stdin);
        switch (menu){
            case 1:
            while(k==0){
            fflush(stdin);
            printf("\nDigite o numero da linhas a qual a celula pertence:\n");
            scanf("%d",&m);
            if(m>=lin||m<0) printf("A matriz nao possui a linha %d\n",m);
            else k++;}
            k=0;
            while(k==0){
            printf("\nDigite o numero da colunas a qual a celula pertence:\n");
            scanf("%d",&n);
            if(n>=col||n<0) printf("A matriz nao possui a coluna %d\n",n);
            else k++;}
            k=0;
            fflush(stdin);
            pos_el=buscar(m,n,max_el,celula);
            printf("\n\nO valor dessa celula eh:\n%.2f\n",celula[pos_el].valor);
            printf("Deseja altera-lo?(S/N)\n");
            while(k==0){
            scanf("%c",&noyes);
            fflush(stdin);
            if(noyes=='s'||noyes=='S'){
                printf("\n\nEntre com um novo valor para celula:\n");
                scanf("%f",&novo);
                fflush(stdin);
                {if(pos_el==-1){
                    if(novo!=0){
                        if((elem+1)==max_el){
                            max_el=elem+2;
                            celula=(struct matrix*)realloc(max_el,sizeof(struct matrix));
                            if(celula==NULL){printf("\n\n\n\nFALHA NO ARMAZENAMENTO EM MEMORIA!!!"), exit(1);
                        }}celula[elem].i=m;
                        celula[elem].j=n;
                        celula[elem].valor=novo;
                        elem++;}
                    }else{
                        if(novo!=0){
                            celula[pos_el].valor=novo;
                        }else{
                            for(r=pos_el;r<elem;r++){
                            celula[r].i=celula[r+1].i;
                            celula[r].j=celula[r+1].j;
                            celula[r].valor=celula[r+1].valor;
                            }elem--;}
                    }
                }
            k++;
            }else{if(noyes=='n'||noyes=='N')k++;
            else printf("\nOpcao invalida, entre com \"S\" para \"sim\" ou \"N\" para \"nao\"\n");}
            }k=0;
            break;
        case 2:
            while(k==0){
                printf("\nQual a linha da qual gostaria de consultar a soma?\n(\"-1\" exibe a soma de todas as linhas existentes\n");
                scanf("%d",&m);
                if(m>=lin||m<-1) printf("\nEssa linha nao existe na matriz\n\n");
                else k++;
            }k=0;
            if(m==-1){
                for(k=0;k<lin;k++){
                    soma=som_lin(k,elem,celula);
                    printf("\nA soma da linha %d eh:\n%.2f\n",k,soma);
                }
            }else {
            soma=som_lin(m,elem,celula);
            printf("\nA soma da linha %d eh:\n%.2f\n",m,soma);}
            m=0;
            break;
        case 3:
            while(k==0){
                printf("\nQual a coluna da qual gostaria de consultar a soma?\n(\"-1\" exibe a soma de todas as colunas existentes\n");
                scanf("%d",&n);
                if(n>=col||n<-1) printf("\nEssa coluna nao existe na matriz\n\n");
                else k++;
            }k=0;
            if(n==-1){
                for(k=0;k<col;k++){
                    soma=som_col(k,elem,celula);
                    printf("\nA soma da coluna %d eh:\n%.2f\n",k,soma);
                }
            }else{
            soma=som_col(n,elem,celula);
            printf("\nA soma da coluna %d eh:\n%.2f\n",n,soma);}
            n=0;
            break;
        case 0:
            k=0;
            printf("\n\nA matriz sera apagada e programa encerrado, deseja realmente sair?(S/N)\n");
            while(k==0){
                scanf("%c",&noyes);
                fflush(stdin);
                if(noyes=='s'||noyes=='S'){
                        j++;
                        k++;}
                else{
                    if(noyes=='n'||noyes=='N') k++;
                    else printf("\nOpcao invalida, entre com \"S\" para \"sim\" ou \"N\" para \"nao\"\n");
                }
            }k=0;
            break;
        default:
            printf("\nOpcao invalida, escolha uma das opcoes do menu!!\n");
            break;


        }


    }while(j==0);

free(celula);
return 0;
}


int buscar(int m, int n, int max_el, struct matrix *celula)
{   int k;

    for(k=0;k<max_el;k++){
    if(celula[k].i==m&&celula[k].j==n){
        return k;
    }}
    return -1;
}

float som_lin(int m, int elem, struct matrix *celula)
{   int k;
    float resp=0;
    for(k=0;k<elem;k++){
        if(celula[k].i==m){
            resp+=celula[k].valor;
        }
    }
    return resp;
}



float som_col(int n, int elem, struct matrix *celula)
{   int k;
    float resp=0;
    for(k=0;k<elem;k++){
        if(celula[k].j==n){
            resp+=celula[k].valor;
        }
    }
    return resp;
}
