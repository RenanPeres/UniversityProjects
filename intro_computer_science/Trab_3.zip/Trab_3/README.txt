Renan Peres Martins 
NUSP: 10716612
Trabalho de ICC 3

//Matrizes esparsas:
O programa compilado e o c�digo fonte desse apresenta um modelo em
linguagem C que permite criar uma matriz de tamanho indeterminado,
escohido pelo usu�rio, e realizar algumas fun��es especificas com ela
(ver/editar valor de celula, soma de colunas, soma de linhas e exclus�o da matriz)

Para mais informa��es:
ler relat�rio no arquivo compactado;
